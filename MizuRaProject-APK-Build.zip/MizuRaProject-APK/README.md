# MizuRaProject APK

Wrapper WebView untuk index.html / dashboard.html / sw-clear.html (ada di `app/src/main/assets/`).
UI dan logic tidak diubah. APK ini hanya "membungkus" halaman HTML-nya dan terhubung ke
server Termux di `http://127.0.0.1:3000`.

## Cara build APK (tanpa Android Studio)
1. Buat repository baru di GitHub, upload SEMUA isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis saat upload, atau klik *Run workflow*).
3. Tunggu 3-5 menit, lalu buka run-nya -> bagian **Artifacts** -> download `MizuRaProject-APK`.
4. Extract zip-nya, install `app-debug.apk` di HP.

## Cara build lewat Android Studio
Open folder ini -> Build -> Build APK(s).

## Catatan
- Tampilan memakai Tailwind CDN & Google Fonts, jadi HP perlu internet saat aplikasi dibuka.
- Jalankan dulu server di Termux (`npm install` lalu `npm start`) sebelum membuka aplikasi.
